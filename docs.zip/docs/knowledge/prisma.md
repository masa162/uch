# データベース関連 (Prisma) 知見集

## 2025年8月18日: Prismaマイグレーションとスキーマ同期の安定化 (TSK-058) からの知見

### 1. 概要
`User`モデルに`role`を追加するタスク（TSK-058）の実施中、`prisma migrate dev`が非対話的環境で失敗する問題に直面した。この解決を通じて、`prisma db push`と`prisma migrate`の適切な使い分けと、既存データベースに対するスキーマ変更の安定した適用方法に関する知見を得た。

### 2. 主要な問題と解決策

#### a. 非対話的環境での `prisma migrate dev` の失敗
- **問題:** `prisma migrate dev` コマンドは、開発中のスキーマ変更とマイグレーションファイル生成を対話的に行うため、CI/CDパイプラインやスクリプト実行のような非対話的（non-interactive）環境ではサポートされておらず、エラーで失敗する。
- **解決策:**
    1.  **スキーマの同期:** まず、`npx prisma db push` を実行した。このコマンドはマイグレーションファイルを生成せず、現在のPrismaスキーマの状態を直接データベースに反映させる。これにより、`role`カラムがデータベースに追加された。
    2.  **マイグレーション履歴の整合性確保:** `db push` はマイグレーション履歴（`_prisma_migrations`テーブル）を更新しない。そのため、既存のマイグレーションが未適用であるかのような状態が続く。これを解決するため、`npx prisma migrate resolve --applied <migration_name>` を実行し、既存のマイグレーションを手動で「適用済み」としてマークした。
- **教訓:**
    - **開発初期・スキーマ変更の試行:** `prisma migrate dev` は、ローカル開発環境で対話的にスキーマ変更を試行し、マイグレーションファイルを生成するのに適している。
    - **本番・CI/CD環境への適用:**
        - マイグレーションファイルベースで管理する場合: `prisma migrate deploy` を使用して、未適用のマイグレーションを安全に適用する。
        - スキーマとDBを直接同期させたい場合（マイグレーションファイル不要時）: `prisma db push` が有効。ただし、これはDBスキーマを破壊的に変更する可能性があるため、開発環境や、状態をリセットしても良いステージング環境での使用が推奨される。
    - **履歴の不整合:** `db push` を使用した後は、`migrate status` を確認し、必要に応じて `migrate resolve` でマイグレーション履歴の整合性を手動で保つ必要がある。

#### b. 既存データベースへの `migrate deploy` の失敗
- **問題:** データベースが空ではない状態で `prisma migrate deploy` を実行しようとすると、「The database schema is not empty.」というエラー（P3005）が発生した。
- **原因:** `migrate deploy` は、クリーンなデータベースにマイグレーションを適用することを想定しているため。
- **解決策（ベースライン設定）:** このような場合、`prisma migrate baseline` コマンドを使用して、既存のデータベーススキーマを特定のマイグレーションの「ベースライン」として設定する必要がある。今回は `db push` で直接スキーマを更新したため、この手順は不要だったが、本番環境で手動変更が加わったDBにPrismaマイグレーションを導入する際の標準的なプラクティスである。
- **教訓:** 稼働中のデータベースにPrismaマイグレーションを導入する際は、`migrate baseline` の概念を理解し、慎重に適用する必要がある。

### 3. 最終的なワークフロー
1.  `prisma/schema.prisma` を編集してモデルを変更する。
2.  開発環境で `npx prisma db push` を実行し、DBスキーマを即座に同期させる。
3.  `npx prisma migrate status` でマイグレーションの状態を確認する。
4.  必要に応じて `npx prisma migrate resolve --applied <migration_name>` を実行し、履歴の整合性を取る。
5.  本番環境へのデプロイ時には、生成されたマイグレーションファイルを元に `npx prisma migrate deploy` を実行する。

この手順により、開発の迅速性（`db push`）と本番の安全性・再現性（`migrate deploy`）を両立できる。

## 2025年8月18日: 記事CRUD機能実装 (TSK-040) からの知見

### 開発環境のデータベース接続
- **問題:** `psql` でのユーザー作成失敗や、`prisma` コマンド実行時の `DATABASE_URL` 環境変数未定義エラーが発生した。
- **解決策:**
    1.  `brew services` でPostgreSQLの起動状態を確認。
    2.  `psql -d postgres` でデフォルトユーザーとして接続し、`CREATE USER` と `CREATE DATABASE` を実行して、アプリケーション用のユーザーとDBを準備した。
    3.  `npx prisma db push` が `.env.local` を読み込まない問題に対し、`DATABASE_URL="postgresql://..." npx prisma db push` のように、コマンドの接頭辞として環境変数を直接指定することで解決した。
- **教訓:** データベースのセットアップは、手順を明確に文書化することが重要。特に、ローカル環境で `prisma` のようなツールが環境変数を正しく読み込めないケースは頻出するため、直接指定する対処法は有効なデバッグ手段となる。

## 2025年8月19日: Windows開発環境のセットアップにおけるPrisma Roleエラーの解決 (TSK-066)

### 問題
MacとWindows間での開発環境の同期が不完全であり、特にPrismaスキーマの`Role` enum定義が未実装であるにも関わらず、コードで既に`Role`を使用していたため、Dockerビルド時にエラーが発生した。

### 原因
- `src/app/api/articles/[slug]/comments/route.ts` で `Role` を `@prisma/client` からインポートしているが、`schema.prisma` に `Role` の定義がなかった。
- ローカル開発環境では認証スキップ設定により正常動作していたが、Dockerビルド時にTypeScriptエラーが発生した。
- これは典型的なプラットフォーム間の開発環境同期問題であり、Mac環境で作業したコードがWindows環境に移行された際、データベーススキーマの同期が不完全だったことが根本原因。

### 解決内容
1.  `prisma/schema.prisma` に `Role` enum を追加 (`USER`, `ADMIN`, `GUEST`)。
2.  Userモデルに `role` フィールドを追加（デフォルト: `USER`）。
3.  Prismaマイグレーションを実行 (`npx prisma migrate dev --name add_user_role`)。
4.  Prismaクライアントを再生成 (`npx prisma generate`)。
5.  Dockerビルドを再テスト (`docker-compose build --no-cache`)。

### 結果
- ローカル開発サーバー: `http://localhost:3001` で正常動作。
- Docker環境: ビルド成功、Roleエラー解決。
- Windows環境: 正常にセットアップ完了。

### 今後の推奨事項
環境移行時のチェックリストとして以下を推奨する:
1.  Prismaスキーマの同期確認
2.  マイグレーション状態の確認
3.  環境変数ファイルの差分確認